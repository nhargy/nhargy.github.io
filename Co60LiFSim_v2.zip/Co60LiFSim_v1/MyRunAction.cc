#include "MyRunAction.hh"
#include "G4AnalysisManager.hh"
#include "G4SystemOfUnits.hh"

MyRunAction::MyRunAction()
 : G4UserRunAction()
{
  auto analysisManager = G4AnalysisManager::Instance();
  analysisManager->SetVerboseLevel(0);

  // Set the filename to CSV format (Geant4 will detect the extension)
  analysisManager->SetFileName("output.csv");

  // Disable ntuple merging (not supported for CSV)
  analysisManager->SetNtupleMerging(false);

  // Create an ntuple named "HitData" with columns for event and hit information.
  analysisManager->CreateNtuple("HitData", "Data from each hit");

  analysisManager->CreateNtupleIColumn("eventID");   // Event ID (G4int)
  analysisManager->CreateNtupleIColumn("pdg");       // Particle PDG code
  analysisManager->CreateNtupleSColumn("Generatingparticle");  // Particle name
  analysisManager->CreateNtupleSColumn("interactionType");    // Interaction type
  analysisManager->CreateNtupleDColumn("edep");      // Energy deposit (G4double)
  analysisManager->CreateNtupleDColumn("x");         // x position
  analysisManager->CreateNtupleDColumn("y");         // y position
  analysisManager->CreateNtupleDColumn("z");         // z position
  analysisManager->CreateNtupleDColumn("time");      // Global time

  analysisManager->FinishNtuple();
}

MyRunAction::~MyRunAction() {}

void MyRunAction::BeginOfRunAction(const G4Run* /*run*/)
{
  auto analysisManager = G4AnalysisManager::Instance();
  analysisManager->OpenFile();
}

void MyRunAction::EndOfRunAction(const G4Run* /*run*/)
{
  auto analysisManager = G4AnalysisManager::Instance();
  analysisManager->Write();
  analysisManager->CloseFile();
}
