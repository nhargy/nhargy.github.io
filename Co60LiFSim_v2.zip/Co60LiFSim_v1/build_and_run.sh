#!/usr/bin/env bash
#
# build_and_run.sh
# Example script to clean the build directory, rebuild, and run the Cs137LXeSim application

# 1) Navigate to the build directory (create it if needed)
cd ~/Downloads/Cs137LXeSim
[ -d build ] || mkdir build
cd build

# 2) (Optional) Clean the build directory fully 
#    so you always have a fresh build
rm -rf *

# 3) Re-run CMake with the correct Geant4_DIR
cmake \
  -DGeant4_DIR=~/Downloads/geant4-install/lib/cmake/Geant4 \
  -DGEANT4_BUILD_MULTITHREADED=ON \
  -DGEANT4_INSTALL_DATA=ON \
  ..

# 4) Compile
make -j$(nproc)

# 5) Run the application
#    - If you have a macro file, specify it here, e.g., run.mac
#    - Or just run interactively
./cs137LXeSim run.mac
