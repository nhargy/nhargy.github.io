#include "G4RunManager.hh"
#include "G4UImanager.hh"
#include "DetectorConstruction.hh"
#include "ActionInitialization.hh"
#include "G4SystemOfUnits.hh"
#include "FTFP_BERT.hh"  // <-- Use a built-in physics list

int main(int argc, char** argv) {
    // Construct the default run manager
    G4RunManager* runManager = new G4RunManager;

    // Set mandatory initialization classes
    runManager->SetUserInitialization(new DetectorConstruction());
    runManager->SetUserInitialization(new FTFP_BERT);  // <-- Replaced PhysicsList with a built-in one
    runManager->SetUserInitialization(new ActionInitialization());

    // Initialize G4 kernel
    runManager->Initialize();

    // Get UI manager and initialize
    G4UImanager* uiManager = G4UImanager::GetUIpointer();
    uiManager->ApplyCommand("/run/initialize");

    // Run simulation
    G4int numberOfEvents = 100000;  // Adjust as needed
    runManager->BeamOn(numberOfEvents);

    // Clean up
    delete runManager;
    return 0;
}
