#ifndef MyStackingAction_h
#define MyStackingAction_h 1

#include "G4UserStackingAction.hh"
#include "G4ClassificationOfNewTrack.hh"
#include "G4Track.hh"

class MyStackingAction : public G4UserStackingAction
{
public:
    MyStackingAction();
    virtual ~MyStackingAction();

    // Called for every new track. This is where you attach user information to secondaries.
    virtual G4ClassificationOfNewTrack ClassifyNewTrack(const G4Track* aTrack);

    // These two methods can be overridden if needed.
    virtual void NewStage();
    virtual void PrepareNewEvent();
};

#endif
