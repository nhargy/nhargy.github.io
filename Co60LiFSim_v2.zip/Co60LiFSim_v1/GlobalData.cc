#include "GlobalData.hh"

thread_local G4int gCurrentEventID = 0;
