#include "ActionInitialization.hh"
#include "PrimaryGeneratorAction.hh"
#include "MyStackingAction.hh"
#include "MyRunAction.hh"
#include "MySteppingAction.hh"
#include "MyEventAction.hh"

ActionInitialization::ActionInitialization() : G4VUserActionInitialization() {}

ActionInitialization::~ActionInitialization() {}

void ActionInitialization::Build() const {
    // Primary generator
    SetUserAction(new PrimaryGeneratorAction());

    // Stacking, run, and event actions
    SetUserAction(new MyStackingAction());
    SetUserAction(new MyRunAction());

    // Create and register MyEventAction
    MyEventAction* myEventAction = new MyEventAction();
    SetUserAction(myEventAction);

    // Pass MyEventAction instance to MySteppingAction
    SetUserAction(new MySteppingAction(myEventAction));
}

void ActionInitialization::BuildForMaster() const {
    // For master thread, only run action is needed
    SetUserAction(new MyRunAction());
}
