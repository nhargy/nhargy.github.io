#include "PrimaryGeneratorAction.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4SystemOfUnits.hh"
#include "G4Event.hh"
#include "G4ParticleDefinition.hh"

PrimaryGeneratorAction::PrimaryGeneratorAction()
 : G4VUserPrimaryGeneratorAction()
{
  // Create the particle gun for 1 particle per vertex.
  // (We will call GeneratePrimaryVertex twice per event.)
  fParticleGun = new G4ParticleGun(1);

  // Define the particle type: gamma.
  G4ParticleDefinition* gamma =
    G4ParticleTable::GetParticleTable()->FindParticle("gamma");
  fParticleGun->SetParticleDefinition(gamma);

  // Set a common initial position (for example, +10 cm along the Z axis).
  fParticleGun->SetParticlePosition(G4ThreeVector(0., 0., 10.*cm));

  // Set a common momentum direction (e.g., toward the origin).
  fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0., 0., -1.));
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
  delete fParticleGun;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
  // First gamma: energy ~1.1732 MeV
  fParticleGun->SetParticleEnergy(1.1732*MeV);
  fParticleGun->GeneratePrimaryVertex(anEvent);

  // Second gamma: energy ~1.3325 MeV
  fParticleGun->SetParticleEnergy(1.3325*MeV);
  fParticleGun->GeneratePrimaryVertex(anEvent);
}
