#include "MySteppingAction.hh"
#include "G4Step.hh"
#include "G4SystemOfUnits.hh"  // ✅ Include this for MeV, keV, eV

MySteppingAction::MySteppingAction(MyEventAction* eventAction)
    : fEventAction(eventAction) {}

MySteppingAction::~MySteppingAction() {}

void MySteppingAction::UserSteppingAction(const G4Step* step) {
    G4double edep = step->GetTotalEnergyDeposit();
    if (edep > 0) {

        // Print energy deposition in MeV, keV, and eV
        G4cout << "Energy deposited: "
               << edep / MeV << " MeV, "
               << edep / keV << " keV, "
               << edep / eV  << " eV" << G4endl;

        fEventAction->AddEdep(edep);
    }
}
