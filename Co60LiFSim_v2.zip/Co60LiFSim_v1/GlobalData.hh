#ifndef GLOBALDATA_HH
#define GLOBALDATA_HH

#include "G4Types.hh"

extern thread_local G4int gCurrentEventID;

#endif // GLOBALDATA_HH
