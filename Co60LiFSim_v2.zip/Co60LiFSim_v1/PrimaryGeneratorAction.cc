#include "PrimaryGeneratorAction.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4SystemOfUnits.hh"
#include "G4Gamma.hh"
#include "Randomize.hh"

PrimaryGeneratorAction::PrimaryGeneratorAction() {
    // Initialize the particle gun with one particle per event
    fParticleGun = new G4ParticleGun(1);
}

PrimaryGeneratorAction::~PrimaryGeneratorAction() {
    delete fParticleGun;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent) {
    G4ParticleDefinition* gamma = G4Gamma::GammaDefinition();

    // Set position of the source
    G4ThreeVector position(0, 0, 0);

    // Define the two characteristic gamma-ray energies
    G4double energies[2] = {1.17 * MeV, 1.33 * MeV};

    for (int i = 0; i < 2; i++) {  // Emit both gammas per event
        fParticleGun->SetParticleDefinition(gamma);
        fParticleGun->SetParticleEnergy(energies[i]);

        // Pick a random isotropic direction
        G4double theta = acos(2.0 * G4UniformRand() - 1.0); // Uniform over sphere
        G4double phi = 2.0 * M_PI * G4UniformRand();
        G4ThreeVector direction(sin(theta) * cos(phi), sin(theta) * sin(phi), cos(theta));

        fParticleGun->SetParticleMomentumDirection(direction);
        fParticleGun->SetParticlePosition(position);

        fParticleGun->GeneratePrimaryVertex(anEvent);
    }
}
