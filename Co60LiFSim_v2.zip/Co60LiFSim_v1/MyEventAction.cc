#include "MyEventAction.hh"
#include "G4Event.hh"
#include "G4AnalysisManager.hh"
#include "G4SystemOfUnits.hh"
#include <cmath> // Needed for std::isnan

MyEventAction::MyEventAction() : total_edep(0) {} // Ensure initialization

MyEventAction::~MyEventAction() {}

void MyEventAction::BeginOfEventAction(const G4Event*) {
    total_edep = 0;  // Reset at the start of each event
}

void MyEventAction::EndOfEventAction(const G4Event* event) {
    G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();

    if (std::isnan(total_edep)) {
        total_edep = 0.0;
    }

    // Get the number of primary particles in this event
    G4int num_primaries = event->GetNumberOfPrimaryVertex();

    G4cout << "Event ID: " << event->GetEventID()
           << ", Total Energy Deposition: " << total_edep / MeV << " MeV"
           << ", Number of Primaries: " << num_primaries << G4endl;

    // Store the event data
    analysisManager->FillNtupleIColumn(0, event->GetEventID());
    analysisManager->FillNtupleDColumn(4, static_cast<G4double>(total_edep));
    analysisManager->AddNtupleRow();
}


void MyEventAction::AddEdep(G4double edep) {
    total_edep += edep;
}
