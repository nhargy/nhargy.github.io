#ifndef MYEVENTACTION_HH
#define MYEVENTACTION_HH

#include "G4UserEventAction.hh"
#include "G4Types.hh"
#include "G4Event.hh"

class MyEventAction : public G4UserEventAction {
public:
  MyEventAction();
  virtual ~MyEventAction();

  virtual void BeginOfEventAction(const G4Event* event) override;
  virtual void EndOfEventAction(const G4Event* event) override;

  void AddEdep(G4double edep); // <-- Add this line

private:
  G4double total_edep; // Correctly placed inside the class
};

#endif
