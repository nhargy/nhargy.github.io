// MyStackingAction.cc
#include "MyStackingAction.hh"
#include "MyTrackInformation.hh"
#include "G4Track.hh"

MyStackingAction::MyStackingAction() : G4UserStackingAction() {
  // Initialization (if needed)
}

MyStackingAction::~MyStackingAction() { }

G4ClassificationOfNewTrack MyStackingAction::ClassifyNewTrack(const G4Track* aTrack) {
  // For secondary tracks, attach user information.
  if (aTrack->GetParentID() != 0) {
    G4String parentName = aTrack->GetDynamicParticle()->GetParticleDefinition()->GetParticleName();
    aTrack->SetUserInformation(new MyTrackInformation(parentName));
  }
  return fUrgent;  // Process track immediately
}

void MyStackingAction::NewStage() { }

void MyStackingAction::PrepareNewEvent() { }


