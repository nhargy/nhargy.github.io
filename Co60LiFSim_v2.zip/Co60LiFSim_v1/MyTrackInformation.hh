#ifndef MyTrackInformation_h
#define MyTrackInformation_h 1

#include "G4VUserTrackInformation.hh"
#include "G4String.hh"

class MyTrackInformation : public G4VUserTrackInformation {
public:
    MyTrackInformation(const G4String& parentName)
      : fParentName(parentName) {}
    virtual ~MyTrackInformation() {}

    G4String GetParentName() const { return fParentName; }

private:
    G4String fParentName;
};

#endif

