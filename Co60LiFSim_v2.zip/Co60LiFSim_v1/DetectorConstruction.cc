#include "DetectorConstruction.hh"
#include "G4Material.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"

DetectorConstruction::DetectorConstruction() {}

DetectorConstruction::~DetectorConstruction() {}

G4VPhysicalVolume* DetectorConstruction::Construct() {
    G4NistManager* nist = G4NistManager::Instance();

    // Define Lithium Fluoride (LiF) material
    G4Material* LiF = new G4Material("LithiumFluoride", 2.635 * g/cm3, 2);
    LiF->AddElement(nist->FindOrBuildElement("Li"), 1);
    LiF->AddElement(nist->FindOrBuildElement("F"), 1);

    // Define world volume (filled with air)
    G4Material* air = nist->FindOrBuildMaterial("G4_AIR");
    G4Box* solidWorld = new G4Box("World", 1.5*m, 1.5*m, 1.5*m);
    G4LogicalVolume* logicWorld = new G4LogicalVolume(solidWorld, air, "World");
    G4VPhysicalVolume* physWorld = new G4PVPlacement(nullptr, G4ThreeVector(), logicWorld, "World", nullptr, false, 0);

    // Define LiF detector cube (1 cm³)
    G4double detector_size = 0.25 * cm; // Half-length of the 1 cm cube
    G4Box* solidDetector = new G4Box("Detector", detector_size, detector_size, detector_size);
    G4LogicalVolume* logicDetector = new G4LogicalVolume(solidDetector, LiF, "Detector");

    // Place detector at (40 cm, 0, 0)
    new G4PVPlacement(nullptr, G4ThreeVector(27.0 * cm, 0, 0), logicDetector, "Detector", logicWorld, false, 0);

    return physWorld;
}
