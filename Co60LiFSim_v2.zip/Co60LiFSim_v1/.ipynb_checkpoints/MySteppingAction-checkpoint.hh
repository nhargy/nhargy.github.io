#ifndef MYSTEPPINGACTION_HH
#define MYSTEPPINGACTION_HH

#include "G4UserSteppingAction.hh"

class MySteppingAction : public G4UserSteppingAction {
public:
  MySteppingAction();
  virtual ~MySteppingAction();

  virtual void UserSteppingAction(const G4Step* aStep) override;
};

#endif
