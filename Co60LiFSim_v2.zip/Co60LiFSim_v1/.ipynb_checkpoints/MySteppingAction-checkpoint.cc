/*#include "MySteppingAction.hh"
#include "G4Step.hh"
#include "G4AnalysisManager.hh"
#include "G4StepPoint.hh"
#include "GlobalData.hh"         // for gCurrentEventID
#include "MyTrackInformation.hh" // to retrieve parent information
#include "G4VProcess.hh"           // Include full definition for G4VProcess


// Constructor
MySteppingAction::MySteppingAction() : G4UserSteppingAction() { }

// Destructor
MySteppingAction::~MySteppingAction() { }

void MySteppingAction::UserSteppingAction(const G4Step* aStep)
{
    G4cout << "!!!!!!!!!!!!! In stepping action !!!!!!!!!!!!!: " << G4endl;
    G4cout.flush();
  // ... (your previous code) ...

  // Retrieve the process (which defines the interaction type)
  const G4VProcess* proc = aStep->GetPostStepPoint()->GetProcessDefinedStep();
  G4String interactionType = proc ? proc->GetProcessName() : "None";

  // (Set generatingParticle using your logic)
  const G4Track* track = aStep->GetTrack();
  G4ParticleDefinition* particleDef = track->GetDefinition();
  G4String generatingParticle = particleDef->GetParticleName();
  MyTrackInformation* trackInfo = dynamic_cast<MyTrackInformation*>(track->GetUserInformation());
  if (trackInfo) {
    const char* parentName = trackInfo->GetParentName();
    if (parentName) {
      G4cout << "Parent name: " << parentName << G4endl;
      generatingParticle = G4String(parentName);
    } else {
      G4cout << "Warning: Parent name is null!" << G4endl;
      generatingParticle = particleDef->GetParticleName();
    }
  } else {
    generatingParticle = particleDef->GetParticleName();
  }

  // Debug: print out the values before filling the ntuple.
  G4cout << "Filling ntuple with:" << G4endl;
  G4cout << "  EventID: " << gCurrentEventID << G4endl;
  G4cout << "  PDG: " << particleDef->GetPDGEncoding() << G4endl;
  G4cout << "  Generating Particle: '" << generatingParticle << "'" << G4endl;
  G4cout << "  Interaction Type: '" << interactionType << "'" << G4endl;

  // Now fill the ntuple columns:
  auto analysisManager = G4AnalysisManager::Instance();
  analysisManager->FillNtupleIColumn(0, gCurrentEventID);
  analysisManager->FillNtupleIColumn(1, particleDef->GetPDGEncoding());
  analysisManager->FillNtupleSColumn(2, generatingParticle.c_str());
  analysisManager->FillNtupleSColumn(3, interactionType.c_str());
  analysisManager->FillNtupleDColumn(4, aStep->GetTotalEnergyDeposit());
  analysisManager->FillNtupleDColumn(5, aStep->GetPreStepPoint()->GetPosition().x());
  analysisManager->FillNtupleDColumn(6, aStep->GetPreStepPoint()->GetPosition().y());
  analysisManager->FillNtupleDColumn(7, aStep->GetPreStepPoint()->GetPosition().z());
  analysisManager->FillNtupleDColumn(8, aStep->GetPreStepPoint()->GetGlobalTime());
  analysisManager->AddNtupleRow();
}*/


#include "MySteppingAction.hh"
#include "G4Step.hh"
#include "G4AnalysisManager.hh"
#include "G4StepPoint.hh"
#include "GlobalData.hh"         
#include "MyTrackInformation.hh" 
#include "G4VProcess.hh"

// Constructor
MySteppingAction::MySteppingAction() : G4UserSteppingAction() { }

// Destructor
MySteppingAction::~MySteppingAction() { }

void MySteppingAction::UserSteppingAction(const G4Step* aStep)
{
    // Get position and compute radius
    G4StepPoint* prePoint = aStep->GetPreStepPoint();
    G4ThreeVector pos = prePoint->GetPosition();
    G4double radius = pos.mag();  // Radius from the origin

    // Check if within 10 mm radius and inside LXe medium
    G4String volumeName = prePoint->GetPhysicalVolume()->GetName();
    if (volumeName == "LXeSpherePhysical") {
        G4double edep = aStep->GetTotalEnergyDeposit();
        //if (edep == 0.) return;

        const G4Track* track = aStep->GetTrack();
        G4ParticleDefinition* particleDef = track->GetDefinition();
        G4String generatingParticle = particleDef->GetParticleName();

        MyTrackInformation* trackInfo = dynamic_cast<MyTrackInformation*>(track->GetUserInformation());
        if (trackInfo) {
            const char* parentName = trackInfo->GetParentName();
            generatingParticle = parentName ? G4String(parentName) : particleDef->GetParticleName();
        }

        const G4VProcess* proc = aStep->GetPostStepPoint()->GetProcessDefinedStep();
        G4String interactionType = proc ? proc->GetProcessName() : "None";

        // Fill the ntuple only for selected events
        auto analysisManager = G4AnalysisManager::Instance();
        analysisManager->FillNtupleIColumn(0, gCurrentEventID);
        analysisManager->FillNtupleIColumn(1, particleDef->GetPDGEncoding());
        analysisManager->FillNtupleSColumn(2, generatingParticle.c_str());
        analysisManager->FillNtupleSColumn(3, interactionType.c_str());
        analysisManager->FillNtupleDColumn(4, edep);
        analysisManager->FillNtupleDColumn(5, pos.x());
        analysisManager->FillNtupleDColumn(6, pos.y());
        analysisManager->FillNtupleDColumn(7, pos.z());
        analysisManager->FillNtupleDColumn(8, prePoint->GetGlobalTime());
        analysisManager->AddNtupleRow();
    }
}
