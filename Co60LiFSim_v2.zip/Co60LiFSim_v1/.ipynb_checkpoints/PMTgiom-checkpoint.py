import numpy as np

class PMTs():
    def __init__(self):
        self.r=21/40
        self.mirror=[17,18,19,13,14,15,16,12,11,10,7,8,9,3,4,5,6,0,1,2,21,20]
        self.mid=np.array([[1/np.sqrt(2)*np.cos(120*np.pi/180), 1/np.sqrt(2)*np.sin(120*np.pi/180), 1/np.sqrt(2)],
                        [-1/np.sqrt(2), 0, 1/np.sqrt(2)],
                        [1/np.sqrt(2)*np.cos(240*np.pi/180), 1/np.sqrt(2)*np.sin(240*np.pi/180), 1/np.sqrt(2)],
                        [0,1,0],
                        [-1/np.sqrt(2), 1/np.sqrt(2), 0],
                        [-1,0,0],
                        [-1/np.sqrt(2), -1/np.sqrt(2),0],
                        [1/np.sqrt(2)*np.cos(120*np.pi/180), 1/np.sqrt(2)*np.sin(120*np.pi/180), -1/np.sqrt(2)],
                        [-1/np.sqrt(2), 0, -1/np.sqrt(2)],
                        [1/np.sqrt(2)*np.cos(240*np.pi/180), 1/np.sqrt(2)*np.sin(240*np.pi/180), -1/np.sqrt(2)],
                        [1/np.sqrt(2)*np.cos(300*np.pi/180), 1/np.sqrt(2)*np.sin(300*np.pi/180), 1/np.sqrt(2)],
                        [1/np.sqrt(2), 0,1/np.sqrt(2)],
                        [1/np.sqrt(2)*np.cos(60*np.pi/180), 1/np.sqrt(2)*np.sin(60*np.pi/180), 1/np.sqrt(2)],
                        [0, -1, 0],
                        [1/np.sqrt(2), -1/np.sqrt(2), 0],
                        [1, 0, 0],
                        [1/np.sqrt(2), 1/np.sqrt(2), 0],
                        [1/np.sqrt(2)*np.cos(300*np.pi/180), 1/np.sqrt(2)*np.sin(300*np.pi/180), -1/np.sqrt(2)],
                        [1/np.sqrt(2), 0, -1/np.sqrt(2)],
                        [1/np.sqrt(2)*np.cos(60*np.pi/180), 1/np.sqrt(2)*np.sin(60*np.pi/180), -1/np.sqrt(2)]                        ])


        self.right=np.zeros((20,3))
        self.up=np.zeros((20,3))

        for i in range(20):
            a=self.mid[i][0]
            b=self.mid[i][1]
            self.right[i]=[-0.5*self.r*b/np.sqrt(a**2+b**2), 0.5*self.r*a/np.sqrt(a**2+b**2), 0]
            self.up[i]=np.cross(self.mid[i], self.right[i])
        
        n=20
        cos, phi=np.meshgrid(np.linspace(-0.9,0.9,n), np.linspace(0,2*np.pi,n, endpoint=False))
        x=np.ravel(np.cos(phi)*np.sin(np.arccos(cos)))
        y=np.ravel(np.sin(phi)*np.sin(np.arccos(cos)))
        z=np.ravel(cos)
        self.mesh=np.vstack((np.vstack((x,y,z)).T, np.array([[0,0,1], [0,0,-1]])))       
        
    def make_phi(self,d):
        phi=np.zeros(d.shape[0])+10
        phi[d[:,0]>0]=np.arctan(d[d[:,0]>0,1]/d[d[:,0]>0,0])
        phi[np.logical_and(d[:,0]<0, d[:,1]>=0)]=np.arctan(d[np.logical_and(d[:,0]<0, d[:,1]>=0),1]/
                                                           d[np.logical_and(d[:,0]<0, d[:,1]>=0),0])+np.pi
        phi[np.logical_and(d[:,0]<0, d[:,1]<0)]=np.arctan(d[np.logical_and(d[:,0]<0, d[:,1]<0),1]/
                                                          d[np.logical_and(d[:,0]<0, d[:,1]<0),0])-np.pi
        phi[np.logical_and(d[:,0]==0, d[:,1]>=0)]=np.pi/2
        phi[np.logical_and(d[:,0]==0, d[:,1]<0)]=-np.pi/2
        return phi

    def whichPMT(self,v, us):
        # v is 1,3
        hits=np.zeros(len(us[0]))-1
        for i in range(len(self.mid)):
            a=(1-np.sum(v*self.mid[i]))/np.sum(us.T*self.mid[i], axis=1) # N length
            r=v+(a*us).T-self.mid[i] # (N,3)
            hits[np.nonzero(np.logical_and(a>0,
            np.logical_and(np.abs(np.sum(r*self.right[i], axis=1))<np.sum(self.right[i]**2),
             np.abs(np.sum(r*self.up[i], axis=1))<np.sum(self.up[i]**2))))[0]]=i
        return hits