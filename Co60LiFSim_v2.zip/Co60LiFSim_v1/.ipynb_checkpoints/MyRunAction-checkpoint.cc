#include "MyRunAction.hh"
#include "G4AnalysisManager.hh"
#include "G4SystemOfUnits.hh"

MyRunAction::MyRunAction()
 : G4UserRunAction()
{
  auto analysisManager = G4AnalysisManager::Instance();
  analysisManager->SetVerboseLevel(0);
  analysisManager->SetNtupleMerging(true);
  // Optionally, if you want CSV output, you might set:
  // analysisManager->SetFileType("csv");

  // Set the file name; the extension may be determined by the file type
  analysisManager->SetFileName("output.csv");

  // Create an ntuple named "HitData" with columns for energy deposit and position/time.
  analysisManager->CreateNtuple("HitData", "Data from each hit");
  analysisManager->CreateNtupleIColumn("eventID");      // Event ID
  analysisManager->CreateNtupleIColumn("pdg");          // Particle PDG code (if applicable)
  analysisManager->CreateNtupleSColumn("Generatingparticle"); // Name of the particle generated (e.g. "photon", "electron", etc.)
  analysisManager->CreateNtupleSColumn("interactionType");   // Type of interaction (e.g. "Compton", "Photoelectric", etc.)
  analysisManager->CreateNtupleDColumn("edep");         // Energy deposit
  analysisManager->CreateNtupleDColumn("x");            // x position
  analysisManager->CreateNtupleDColumn("y");            // y position
  analysisManager->CreateNtupleDColumn("z");            // z position
  analysisManager->CreateNtupleDColumn("time");         // Global time
  analysisManager->FinishNtuple();
}

MyRunAction::~MyRunAction()
{
  // Typically no manual deletion is needed.
}

void MyRunAction::BeginOfRunAction(const G4Run* /*run*/)
{
  auto analysisManager = G4AnalysisManager::Instance();
  analysisManager->OpenFile();
}

void MyRunAction::EndOfRunAction(const G4Run* /*run*/)
{
  auto analysisManager = G4AnalysisManager::Instance();
  analysisManager->Write();
  analysisManager->CloseFile();
}
