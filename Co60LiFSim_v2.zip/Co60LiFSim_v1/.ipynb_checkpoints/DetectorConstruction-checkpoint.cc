#include "DetectorConstruction.hh"

#include "G4NistManager.hh"
#include "G4Material.hh"
#include "G4SystemOfUnits.hh"
#include "G4PhysicalConstants.hh"
#include "G4Orb.hh"
#include "G4Box.hh"
#include "G4Sphere.hh"  // Include for the silica shell
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4ThreeVector.hh"

DetectorConstruction::DetectorConstruction()
 : G4VUserDetectorConstruction()
{}

DetectorConstruction::~DetectorConstruction()
{}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
  G4cout << "!!!!!!!!!!!!! In Detector Construction !!!!!!!!!!!!!: " << G4endl;
  // 1) Materials
  auto nistManager = G4NistManager::Instance();
  
  // Air
  G4Material* air = nistManager->FindOrBuildMaterial("G4_AIR");
  
  // Liquid Xenon (approx) – define from scratch
  G4double lxeDensity = 2.94*g/cm3;
  G4double atomicNumber = 54;
  G4double molWeight = 131.293*g/mole;
  auto lxe = new G4Material("LXe", atomicNumber, molWeight, lxeDensity);

  // Silica
  G4Material* silica = nistManager->FindOrBuildMaterial("G4_SILICON_DIOXIDE");

  // 2) World Volume
  G4double worldSize = 50*cm;
  auto worldSolid = new G4Box("World",
                              0.5*worldSize,
                              0.5*worldSize,
                              0.5*worldSize);
  auto worldLogic = new G4LogicalVolume(worldSolid, air, "WorldLogic");
  auto worldPhys = new G4PVPlacement(
    nullptr,             // no rotation
    G4ThreeVector(),     // at (0,0,0)
    worldLogic,          // its logical volume
    "WorldPhysical",     // name
    nullptr,             // no mother volume
    false,               // no boolean operations
    0,                   // copy number
    true                 // check overlaps
  );

  // 3) LXe Sphere, radius = 1 cm
  G4double sphereRadius = 1.*cm;
  auto sphereSolid = new G4Orb("LXeSphere", sphereRadius);
  auto sphereLogic = new G4LogicalVolume(sphereSolid, lxe, "LXeSphereLogic");
  new G4PVPlacement(
    nullptr,                 // no rotation
    G4ThreeVector(0,0,0),    // place at origin
    sphereLogic,             // logical volume
    "LXeSpherePhysical",     // name
    worldLogic,              // mother volume
    false,
    0,
    true
  );

  // 4) Silica Shell around the LXe sphere
  // Shell inner radius equals the LXe sphere radius (1 cm) and outer radius is 1 cm + 20 mm = 3 cm.
  G4double shellInnerRadius = sphereRadius;
  G4double shellThickness = 20*mm;
  G4double shellOuterRadius = sphereRadius + shellThickness;
  auto shellSolid = new G4Sphere("SilicaShell", 
                                 shellInnerRadius, 
                                 shellOuterRadius,
                                 0.*deg, 360.*deg,   // full phi angle
                                 0.*deg, 180.*deg);  // full theta angle
  auto shellLogic = new G4LogicalVolume(shellSolid, silica, "SilicaShellLogic");
  new G4PVPlacement(
    nullptr,
    G4ThreeVector(0,0,0),
    shellLogic,
    "SilicaShellPhysical",
    worldLogic,
    false,
    0,
    true
  );

  // Return world
  return worldPhys;
}
