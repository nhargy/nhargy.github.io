#include "PrimaryGeneratorAction.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4SystemOfUnits.hh"
#include "G4Event.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"

PrimaryGeneratorAction::PrimaryGeneratorAction()
 : G4VUserPrimaryGeneratorAction()
{
  // Create the particle gun for 1 particle per vertex.
  // (We will call GeneratePrimaryVertex twice per event.)
  fParticleGun = new G4ParticleGun(1);

  // Define the particle type: gamma.
  G4ParticleDefinition* gamma =
    G4ParticleTable::GetParticleTable()->FindParticle("gamma");
  fParticleGun->SetParticleDefinition(gamma);

  // Set a common initial position (for example, +10 cm along the Z axis).
  fParticleGun->SetParticlePosition(G4ThreeVector(0., 0., 10.*cm));

  // Set a common momentum direction (e.g., toward the origin).
  fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0., 0., -1.));
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
  delete fParticleGun;
}

G4ThreeVector RandomDirection() {
    G4double cosTheta = 2.0 * G4UniformRand() - 1.0;  // Uniform in [-1,1]
    G4double sinTheta = std::sqrt(1.0 - cosTheta * cosTheta);
    G4double phi = 2.0 * CLHEP::pi * G4UniformRand(); // Uniform in [0, 2π]

    return G4ThreeVector(sinTheta * std::cos(phi),
                         sinTheta * std::sin(phi),
                         cosTheta);
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent) {
    G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
    G4ParticleDefinition* gammaParticle = particleTable->FindParticle("gamma");

    // Set first gamma: 1173 keV
    fParticleGun->SetParticleDefinition(gammaParticle);
    fParticleGun->SetParticleEnergy(1173.2 * keV);
    fParticleGun->SetParticleMomentumDirection(RandomDirection());
    fParticleGun->GeneratePrimaryVertex(anEvent);

    // Set second gamma: 1332 keV
    fParticleGun->SetParticleEnergy(1332.5 * keV);
    fParticleGun->SetParticleMomentumDirection(RandomDirection());
    fParticleGun->GeneratePrimaryVertex(anEvent);
}
