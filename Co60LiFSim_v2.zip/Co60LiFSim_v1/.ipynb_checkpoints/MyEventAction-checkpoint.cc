#include "MyEventAction.hh"
#include "G4Event.hh"
#include "GlobalData.hh"   // This contains the thread_local variable for event ID
#include "G4ios.hh"     // For G4cout, if you want to print messages
#include "GlobalData.hh"


MyEventAction::MyEventAction()
  : G4UserEventAction()
{
  // Constructor code if needed.
}

MyEventAction::~MyEventAction()
{
  // Destructor code if needed.
}

void MyEventAction::BeginOfEventAction(const G4Event* event)
{
  // Store the current event ID in a global or thread-local variable.
  gCurrentEventID = event->GetEventID();
  
  // Optionally, print out the event ID for debugging.
  G4cout << "Begin of event: " << event->GetEventID() << G4endl;
}

void MyEventAction::EndOfEventAction(const G4Event* event)
{
  G4cout << "End of event: " << event->GetEventID() << G4endl;
}
