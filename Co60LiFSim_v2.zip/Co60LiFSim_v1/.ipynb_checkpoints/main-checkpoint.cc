#include "G4RunManagerFactory.hh"
#include "G4UImanager.hh"
#include "G4VisExecutive.hh"
#include "G4UIExecutive.hh"

#include "DetectorConstruction.hh"
#include "ActionInitialization.hh"

#include "G4PhysListFactory.hh"
#include "G4VModularPhysicsList.hh"
#include "FTFP_BERT.hh"


int main(int argc, char** argv)
{
  G4cout << "!!!!!!!!!!!!! In main !!!!!!!!!!!!!: " << G4endl;
  G4UIExecutive* ui = nullptr;
  if (argc == 1) {
    ui = new G4UIExecutive(argc, argv);
  }

  // Create the Run Manager
  auto runManager = G4RunManagerFactory::CreateRunManager();

  // Set mandatory initialization classes
  runManager->SetUserInitialization(new DetectorConstruction());
  //G4cout << "!!!!!!!!!!!!! After  runManager->SetUserInitialization(new DetectorConstruction()) !!!!!!!!!!!!!: " << G4endl;
  // Create a physics list using the factory
  G4PhysListFactory factory;
  //G4VModularPhysicsList* physicsList = factory.GetReferencePhysList("FTFP_BERT");
  G4VModularPhysicsList* physicsList = new FTFP_BERT;

  runManager->SetUserInitialization(physicsList);

  // Register Action Initialization (which now registers the stacking action internally)
  runManager->SetUserInitialization(new ActionInitialization());
  
  // Do not register MyStackingAction directly here!

  // Initialize G4 kernel
  runManager->Initialize();

  // Visualization manager (optional)
  G4VisManager* visManager = new G4VisExecutive;
  visManager->Initialize();

  // UI Manager commands
  G4UImanager* UImanager = G4UImanager::GetUIpointer();
  UImanager->ApplyCommand("/run/verbose 0");
  UImanager->ApplyCommand("/event/verbose 0");
  UImanager->ApplyCommand("/tracking/verbose 0");

  if (ui) {
    ui->SessionStart();
    delete ui;
  } else {
    G4String macroFile = argv[1];
    G4String command = "/control/execute " + macroFile;
    UImanager->ApplyCommand(command);
  }

  // Cleanup
  delete visManager;
  delete runManager;
  return 0;
}
