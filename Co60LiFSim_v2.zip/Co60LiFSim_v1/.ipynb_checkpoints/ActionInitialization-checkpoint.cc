
#include "ActionInitialization.hh"
#include "PrimaryGeneratorAction.hh"
#include "MyStackingAction.hh"    // Include your stacking action here
#include "MyRunAction.hh"
#include "MySteppingAction.hh"
#include "MyEventAction.hh"

ActionInitialization::ActionInitialization() : G4VUserActionInitialization() { }
ActionInitialization::~ActionInitialization() { }

void ActionInitialization::Build() const {
    SetUserAction(new PrimaryGeneratorAction());
    SetUserAction(new MyStackingAction()); 
    SetUserAction(new MyRunAction());
    SetUserAction(new MyEventAction());
    SetUserAction(new MySteppingAction());
}

void ActionInitialization::BuildForMaster() const {
    // For master thread, typically only the run action is needed.
    SetUserAction(new MyRunAction());
}
