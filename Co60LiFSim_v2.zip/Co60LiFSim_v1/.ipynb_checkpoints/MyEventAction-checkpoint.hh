#ifndef MYEVENTACTION_HH
#define MYEVENTACTION_HH

#include "G4UserEventAction.hh"

// Forward declaration of G4Event to avoid including the full header here.
class G4Event;

class MyEventAction : public G4UserEventAction {
public:
  MyEventAction();
  virtual ~MyEventAction();

  // Called at the beginning of each event
  virtual void BeginOfEventAction(const G4Event* event) override;
  
  // Called at the end of each event
  virtual void EndOfEventAction(const G4Event* event) override;
};

#endif // MYEVENTACTION_HH
