SYSTEM PARAMS:

* Laser Power            : Max
* Laser Wavelength  : 445nm
* ND Filters                : 0.5 + 0.3
* Optical filters          : SP500 after laser, ?LP500 after crystal?

PHASE-   I

irrad1: 10.0min

irrad2: 10.5min

irrad3: 10.3min

PHASE- II

irrad 1: 71.72 Hrs

PHASE-III

PHASE- IV

PHASE-  V
