Two initial 1cm LiFs to test whether we see a 60min gamma irradiation signal.

MISC contains a 1cm sapphire crystal.

Flow:

3 X 0.5 sec
3 X 2 sec
3 X 8 sec

60 min irrad Co60

3 X 0.5 sec
3 X 2 sec
3 X 8 sec