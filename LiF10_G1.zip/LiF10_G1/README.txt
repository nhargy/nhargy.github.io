LiF10_G1 Experiment

ND FILTER 0.8!!! (before shutter, sample)

Samples:

Irrad:
LiF10_102
LiF10_103
LiF10_104

Ctrl:
LiF10_105

-------------------------------------------
Collection Structure:

BL: 1 x 60sec
AM: 1 x 60sec
H2O: power + 5 x 0.5sec
LiFs: power + 5 x 60sec

Irradiation:

Co-60 source. 15mins. Magenta holder.

POWER MEASURED BEFORE EACH SET OF ITERATIONS.

----------------------------------------------

Coll1

irrad 15mins Co60

Coll2

Added 500nm LPF on top of 450nm LPF

Coll3

irrad 15 mins Co60

Coll4

irrad 60 mins Co60

Coll5
